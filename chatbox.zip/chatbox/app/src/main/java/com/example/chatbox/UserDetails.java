package com.example.chatbox;

public class UserDetails {
    static String username = "";
    static String password = "";
    static String chatWith = "";
}
